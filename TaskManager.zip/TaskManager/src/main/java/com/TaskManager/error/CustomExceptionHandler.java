package com.TaskManager.error;

public class CustomExceptionHandler {

}
