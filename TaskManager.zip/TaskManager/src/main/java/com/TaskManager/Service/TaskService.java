package com.TaskManager.Service;

import org.apache.catalina.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.TaskManager.Dao.TaskRepository;
import com.TaskManager.Dao.UserRepository;
import com.TaskManager.entities.Task;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class TaskService {

    private final TaskRepository taskRepository;

    @Autowired
    public TaskService(TaskRepository taskRepository) {
        this.taskRepository = taskRepository;
    }

    public List<Task> getAllTasks() {
        return taskRepository.findAll();
    }

    public Task createTask(Task task) {
        return taskRepository.save(task);
    }

    public Task updateTask(Long taskId, Task updatedTask) {
        Optional<Task> existingTask = taskRepository.findById(taskId);
        if (existingTask.isPresent()) {
            Task taskToUpdate = existingTask.get();
            taskToUpdate.setTitle(updatedTask.getTitle());
            taskToUpdate.setDescription(updatedTask.getDescription());
            taskToUpdate.setDueDate(updatedTask.getDueDate());
            taskToUpdate.setStatus(updatedTask.getStatus());

            if ("Completed".equals(updatedTask.getStatus())) {
                taskToUpdate.setCompletedDate(new Date());
            } else {
                taskToUpdate.setCompletedDate(null);
            }

            return taskRepository.save(taskToUpdate);
        } else {
            throw new IllegalArgumentException("Task not found with ID: " + taskId);
        }
    }

    public void deleteTask(Long taskId) {
        Optional<Task> existingTask = taskRepository.findById(taskId);
        if (existingTask.isPresent()) {
            taskRepository.deleteById(taskId);
        } else {
            throw new IllegalArgumentException("Task not found with ID: " + taskId);}
        }
        public Task assignTask(Long taskId, Long userId) {
            Optional<Task> existingTask = taskRepository.findById(taskId);
            Optional<User> assignedUser = UserRepository.findById(userId);

            if (existingTask.isPresent() && assignedUser.isPresent()) {
                Task task = existingTask.get();
                task.setAssignedUser(assignedUser.get());
                return taskRepository.save(task);
            } else {
                throw new IllegalArgumentException("Task or User not found with provided IDs");
            }
        }

        public List<Task> getTasksAssignedToUser(Long userId) {
            return taskRepository.findByAssignedUser_Id(userId);
        }
        
        public Task setTaskProgress(Long taskId, Integer progress) {
            Optional<Task> existingTask = taskRepository.findById(taskId);

            if (existingTask.isPresent()) {
                Task task = existingTask.get();
                if (progress >= 0 && progress <= 100) {
                    task.setProgress(progress);
                    return taskRepository.save(task);
                } else {
                    throw new IllegalArgumentException("Progress percentage should be between 0 and 100.");
                }
            } else {
                throw new IllegalArgumentException("Task not found with ID: " + taskId);
            }
        }

        public List<Task> getOverdueTasks() {
            Date currentDate = new Date();
            return taskRepository.findByDueDateBeforeAndStatusNot(currentDate, "Completed");
        }
        public List<Task> getTasksByStatus(String status) {
            return taskRepository.findByStatus(status);
        }

        public List<Task> getCompletedTasksByDateRange(Date startDate, Date endDate) {
            return taskRepository.findByStatusAndCompletedDateBetween("Completed", startDate, endDate);
        }
        public Map<String, Object> getTaskStatistics() {
            long totalTasks = taskRepository.count();
            long completedTasks = taskRepository.countByStatus("Completed");
            double percentageCompleted = (double) completedTasks / totalTasks * 100;

            Map<String, Object> statistics = new HashMap<>();
            statistics.put("totalTasks", totalTasks);
            statistics.put("completedTasks", completedTasks);
            statistics.put("percentageCompleted", percentageCompleted);

            return statistics;
        }
        public List<Task> getTasksByPriority(String priority) {
            return taskRepository.findByPriorityOrderByDueDateAsc(priority);
        }
    
    }
    }
    
      
        
        

