package com.TaskManager.Controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import com.TaskManager.Service.TaskService;
import com.TaskManager.entities.Task;

import java.sql.Date;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/tasks")
public class TaskController {

    private final TaskService taskService;

    @Autowired
    public TaskController(TaskService taskService) {
        this.taskService = taskService;
    }

    @GetMapping
    public List<Task> getAllTasks() {
        return taskService.getAllTasks();
    }

    @PostMapping
    public Task createTask(@RequestBody Task task) {
        return taskService.createTask(task);
    }

    @PutMapping("/{taskId}")
    public Task updateTask(@PathVariable Long taskId, @RequestBody Task updatedTask) {
        return taskService.updateTask(taskId, updatedTask);
    }
    
    @DeleteMapping("/{taskId}")
    public void deleteTask(@PathVariable Long taskId) {
        taskService.deleteTask(taskId);
    }
    
    @PostMapping("/{taskId}/assign")
    public Task assignTask(@PathVariable Long taskId, @RequestBody Long userId) {
        return taskService.assignTask(taskId, userId);
    }
    @PutMapping("/{taskId}/progress")
    public Task setTaskProgress(@PathVariable Long taskId, @RequestBody Integer progress) {
        return taskService.setTaskProgress(taskId, progress);
    }

    @GetMapping("/overdue")
    public List<Task> getOverdueTasks() {
        return taskService.getOverdueTasks();
    }
    
  @GetMapping("/status/{status}")
        public List<Task> getTasksByStatus(@PathVariable String status) {
            return taskService.getTasksByStatus(status);
        }

        @GetMapping("/completed")
        public List<Task> getCompletedTasksByDateRange(@RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date startDate,
                                                       @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date endDate) {
            return taskService.getCompletedTasksByDateRange(startDate, endDate);
        }
        

        @GetMapping("/statistics")
        public Map<String, Object> getTaskStatistics() {
            return taskService.getTaskStatistics();
        }
        @GetMapping("/priority/{priority}")
        public List<Task> getTasksByPriority(@PathVariable String priority) {
            return taskService.getTasksByPriority(priority);
        }
        
        @RestController
        @RequestMapping("/api/users")
        public class UserController {

            // ... other methods

            @GetMapping("/{userId}/tasks")
            public List<Task> getTasksAssignedToUser(@PathVariable Long userId) {
                return taskService.getTasksAssignedToUser(userId);
            }
        }
    }
