package com.TaskManager.Dao;

import java.util.List;
import java.util.Optional;

import org.apache.catalina.User;

import com.TaskManager.entities.Task;

public interface UserRepository {
	List<Task> findByAssignedUser_Id(Long userId);

	static Optional<User> findById(Long userId) {
		// TODO Auto-generated method stub
		return null;
	}

}
