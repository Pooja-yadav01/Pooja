package com.TaskManager.Dao;
import java.sql.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.TaskManager.entities.Task;

public interface TaskRepository extends JpaRepository<Task, Long> {

	List<Task> findByAssignedUser_Id(Long userId);
	
	
    List<Task> findByDueDateBeforeAndStatusNot(java.util.Date currentDate, String status);


	List<Task> findByStatusAndCompletedDateBetween(String string, java.util.Date startDate, java.util.Date endDate);


	List<Task> findByStatus1(String status);
	
	List<Task> findByStatus(String status);

    List<Task> findByStatusAndCompletedDateBetween(String status, Date startDate, Date endDate);


	long countByStatus(String string);

    List<Task> findByPriorityOrderByDueDateAsc(String priority);
}


	
	

